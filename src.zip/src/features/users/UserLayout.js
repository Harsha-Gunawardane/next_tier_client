import { Outlet } from "react-router-dom"

function UserLayout() {
  return (
    <div>
        <Outlet />
    </div>
  )
}

export default UserLayout