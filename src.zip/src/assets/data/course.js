

const course = [
  {
    id: "01",
    carName: "Physics 2024 - Theory",
    category: "Audi",
    type: "Manual",
    groupSize: 4,
    rentPrice: 89,
    imgUrl: "https://www.ufs.ac.za/images/librariesprovider22/default-album/shutterstock_1140894395.jpg?sfvrsn=554a8521_0",
  },
  {
    id: "02",
    carName: "Physics 2024 - Theory",
    category: "Toyota",
    type: "Manual",
    groupSize: 4,
    rentPrice: 59,
    imgUrl: "https://www.ufs.ac.za/images/librariesprovider22/default-album/shutterstock_1140894395.jpg?sfvrsn=554a8521_0",
  },
  {
    id: "03",
    carName: "Physics 2024 - Theory",
    category: "Bmw",
    type: "Manual",
    groupSize: 4,
    rentPrice: 109,
    imgUrl: "https://www.ufs.ac.za/images/librariesprovider22/default-album/shutterstock_1140894395.jpg?sfvrsn=554a8521_0",
  },
  {
    id: "04",
    carName: "Physics 2024 - Theory",
    category: "Coupe",
    type: "Manual",
    groupSize: 4,
    rentPrice: 99,
    imgUrl: "https://www.ufs.ac.za/images/librariesprovider22/default-album/shutterstock_1140894395.jpg?sfvrsn=554a8521_0",
  },
  {
    id: "05",
    carName: "Physics 2024 - Theory",
    category: "Bmw",
    type: "Manual",
    groupSize: 4,
    rentPrice: 109,
    imgUrl: "https://www.ufs.ac.za/images/librariesprovider22/default-album/shutterstock_1140894395.jpg?sfvrsn=554a8521_0",
  },

];

export default course;
