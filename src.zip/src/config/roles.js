export const ROLES = {
    Admin : 5150,
    Parent : 1924,
    User : 2001,
    Tutor : 1932,
    Staff : 1984,
    Student : 1942
    };