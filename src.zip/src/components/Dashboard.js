import { Box, Container} from "@chakra-ui/react";



const Dashboard = () => {

    return (  
        <Box m='0' p='0' bg={'gray.100'} w={'100%'} h={'200vh'}>
            Dashboard
        </Box>
    )
}

export default Dashboard;

