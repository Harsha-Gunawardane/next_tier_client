import { Link } from "react-router-dom";

const TutorDashboard = () => {
  return (
    <article style={{ padding: "100px" }}>
      <h1>Hi tutor!</h1>
      <p>You Not Found</p>
    
    </article>
  );
};

export default TutorDashboard;
